package cn.lunadeer.dominion.v1_20_1.events.player.Place;

import cn.lunadeer.dominion.api.dtos.flag.Flags;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.block.BlockState;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockMultiPlaceEvent;
import org.bukkit.event.block.BlockPlaceEvent;

import static cn.lunadeer.dominion.misc.Others.checkPrivilegeFlag;

public class NormalBlock implements Listener {
    @EventHandler(priority = EventPriority.LOWEST)
    public void handler(BlockPlaceEvent event) {
        if (event.isCancelled()) return;
        // Never cancel the multi place event of an end portal activation. Paper replaces the
        // inner blocks before firing it, so cancelling would restore the replaced container
        // while its drops already lie on the ground, duplicating the content.
        if (event instanceof BlockMultiPlaceEvent multiPlace && isEndPortalActivation(multiPlace)) return;
        if (Tag.CROPS.isTagged(event.getBlock().getType())) return;
        if (Tag.SAPLINGS.isTagged(event.getBlock().getType())) return;
        Player player = event.getPlayer();
        checkPrivilegeFlag(event.getBlock().getLocation(), Flags.PLACE, player, event);
    }

    private static boolean isEndPortalActivation(BlockMultiPlaceEvent event) {
        Material placed = event.getBlock().getType();
        if (placed == Material.END_PORTAL || placed == Material.END_PORTAL_FRAME) return true;
        for (BlockState state : event.getReplacedBlockStates()) {
            Material type = state.getType();
            if (type == Material.END_PORTAL || type == Material.END_PORTAL_FRAME) return true;
        }
        return false;
    }
}
