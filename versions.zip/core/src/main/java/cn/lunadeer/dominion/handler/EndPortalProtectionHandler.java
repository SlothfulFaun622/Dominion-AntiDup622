package cn.lunadeer.dominion.handler;

import cn.lunadeer.dominion.configuration.Configuration;
import cn.lunadeer.dominion.configuration.Language;
import cn.lunadeer.dominion.utils.Notification;
import cn.lunadeer.dominion.utils.XLogger;
import cn.lunadeer.dominion.utils.configuration.ConfigurationPart;
import cn.lunadeer.dominion.utils.scheduler.Scheduler;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.ChunkSnapshot;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.block.Container;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Prevents the end-portal item duplication caused by Paper's event ordering.
 * <p>
 * When the last eye of ender is inserted, Paper replaces the inner 3x3 blocks BEFORE firing
 * BlockMultiPlaceEvent. Cancelling that event restores the replaced container while its drops
 * are already on the ground, duplicating the content. Since Paper offers no API to stop the
 * replacement without the duplication, the only safe spot is BlockPlaceEvent: we simply do not
 * allow blocks to exist inside a complete but not-yet-activated end portal frame.
 * <p>
 * Once the portal is activated (an END_PORTAL block exists in the middle), placement inside the
 * frame is allowed again so redstone machines like sand dupers keep working.
 */
public class EndPortalProtectionHandler implements Listener {

    public static class EndPortalProtectionHandlerText extends ConfigurationPart {
        public String placeDenied = "&cThe portal frame is not activated yet, you cannot place blocks inside it.";
        public String cooldownApplied = "&cToo many attempts. You are temporarily not allowed to place blocks near end portals ({0}s).";
        public String cooldownDenied = "&cYou are temporarily not allowed to place blocks near end portals ({0}s left).";
    }

    // how many denied attempts inside this window (millis) trigger the temporary restriction
    private static final long STRIKE_WINDOW_MS = 10_000L;
    private static final int STRIKE_LIMIT = 3;
    // the restriction covers the frame itself plus the ring of blocks touching it, so 3 blocks
    // out from the center on every side
    private static final int RESTRICTION_RADIUS = 3;
    // the frame is flat, but blocks are usually stacked on top of it, so one level above counts too
    private static final int RESTRICTION_HEIGHT = 1;

    private final JavaPlugin plugin;

    // attempt bookkeeping for the rate limiter
    private final Map<UUID, long[]> strikes = new HashMap<>();
    private final Map<UUID, Cooldown> cooldowns = new HashMap<>();

    private static class Cooldown {
        long expiresAt;
        Location center;
    }

    public EndPortalProtectionHandler(JavaPlugin plugin) {
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        // wait a moment so every world is fully loaded, then clean the chunks already loaded
        Scheduler.runTaskLater(this::cleanupLoadedChunks, 100L);
    }

    // ---------------------------------------------------------------- events

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        if (!Configuration.endPortalProtection.enable) return;
        Block block = event.getBlockPlaced();
        Player player = event.getPlayer();

        // while restricted, keep the player from dropping blocks around the portal he messed with
        Cooldown cooldown = cooldowns.get(player.getUniqueId());
        if (cooldown != null) {
            long now = System.currentTimeMillis();
            // the restriction belongs to the unactivated portal, once it is lit up it is pointless
            if (now < cooldown.expiresAt && !isActivated(cooldown.center)) {
                if (isAroundFrame(cooldown.center, block.getLocation())) {
                    event.setCancelled(true);
                    long left = (cooldown.expiresAt - now) / 1000L + 1L;
                    Notification.warn(player, Language.endPortalProtectionHandlerText.cooldownDenied, left);
                }
                return;
            }
            cooldowns.remove(player.getUniqueId());
        }

        Location center = findUnactivatedPortal(block.getLocation());
        if (center == null) return;

        event.setCancelled(true);
        Notification.warn(player, Language.endPortalProtectionHandlerText.placeDenied);
        recordStrike(player, center);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        // drop the bookkeeping of leaving players so the maps stay small
        UUID uuid = event.getPlayer().getUniqueId();
        strikes.remove(uuid);
        cooldowns.remove(uuid);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onChunkLoad(ChunkLoadEvent event) {
        if (!Configuration.endPortalProtection.enable) return;
        if (!Configuration.endPortalProtection.cleanExistingStructures) return;
        cleanChunk(event.getChunk());
    }

    // ------------------------------------------------------------ rate limit

    private void recordStrike(Player player, Location center) {
        UUID uuid = player.getUniqueId();
        long now = System.currentTimeMillis();
        long[] record = strikes.computeIfAbsent(uuid, k -> new long[]{0L, 0L});
        if (now - record[1] > STRIKE_WINDOW_MS) {
            record[0] = 0L;
            record[1] = now;
        }
        record[0]++;
        if (record[0] < STRIKE_LIMIT) return;

        strikes.remove(uuid);
        int seconds = Configuration.endPortalProtection.cooldownSeconds;
        Cooldown cooldown = new Cooldown();
        cooldown.expiresAt = now + seconds * 1000L;
        cooldown.center = center;
        cooldowns.put(uuid, cooldown);
        Notification.warn(player, Language.endPortalProtectionHandlerText.cooldownApplied, seconds);
    }

    /**
     * True if the location belongs to the blocks around the frame: the 5x5 portal itself plus the
     * single ring of blocks touching it, at the frame level or directly above it.
     */
    private static boolean isAroundFrame(Location center, Location loc) {
        if (center == null || loc == null) return false;
        if (center.getWorld() == null || !center.getWorld().equals(loc.getWorld())) return false;
        int dy = loc.getBlockY() - center.getBlockY();
        if (dy < 0 || dy > RESTRICTION_HEIGHT) return false;
        return Math.abs(loc.getBlockX() - center.getBlockX()) <= RESTRICTION_RADIUS
                && Math.abs(loc.getBlockZ() - center.getBlockZ()) <= RESTRICTION_RADIUS;
    }

    // --------------------------------------------------------- portal lookup

    /**
     * Checks whether the location sits in the inner 3x3 of a complete end portal frame
     * that has not been activated yet.
     *
     * @return the center of the portal if so, otherwise null
     */
    private static Location findUnactivatedPortal(Location loc) {
        World world = loc.getWorld();
        if (world == null) return null;
        int x = loc.getBlockX();
        int y = loc.getBlockY();
        int z = loc.getBlockZ();
        // the block is inside the 3x3 of the portal, so the center is at most one block away
        for (int cx = x - 1; cx <= x + 1; cx++) {
            for (int cz = z - 1; cz <= z + 1; cz++) {
                if (!isCompleteFrame(world, cx, y, cz)) continue;
                if (isActivated(world, cx, y, cz)) continue;
                return new Location(world, cx, y, cz);
            }
        }
        return null;
    }

    /**
     * Checks the 12 end portal frames around the 3x3 centered at (cx, y, cz).
     * The four corners are empty by design, every frame has to face the center,
     * exactly like the vanilla BlockPattern requires for activation.
     */
    private static boolean isCompleteFrame(World world, int cx, int y, int cz) {
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                boolean onRing = Math.abs(dx) == 2 || Math.abs(dz) == 2;
                boolean isCorner = Math.abs(dx) == 2 && Math.abs(dz) == 2;
                if (!onRing || isCorner) continue;
                Block frame = world.getBlockAt(cx + dx, y, cz + dz);
                if (frame.getType() != Material.END_PORTAL_FRAME) return false;
                BlockData data = frame.getBlockData();
                if (!(data instanceof Directional directional)) return false;
                if (directional.getFacing() != facingOf(dx, dz)) return false;
            }
        }
        return true;
    }

    /**
     * The direction a frame at the given ring offset has to face (towards the center).
     */
    private static BlockFace facingOf(int dx, int dz) {
        if (dz == -2) return BlockFace.SOUTH;
        if (dz == 2) return BlockFace.NORTH;
        if (dx == -2) return BlockFace.EAST;
        return BlockFace.WEST;
    }

    private static boolean isActivated(Location center) {
        if (center == null || center.getWorld() == null) return false;
        return isActivated(center.getWorld(), center.getBlockX(), center.getBlockY(), center.getBlockZ());
    }

    private static boolean isActivated(World world, int cx, int y, int cz) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (world.getBlockAt(cx + dx, y, cz + dz).getType() == Material.END_PORTAL) {
                    return true;
                }
            }
        }
        return false;
    }

    // ------------------------------------------------------- existing blocks

    /**
     * Moves blocks sitting inside unactivated portal frames out of the chunk, so portals
     * built before this patch can no longer be abused either.
     */
    private void cleanupLoadedChunks() {
        if (!Configuration.endPortalProtection.enable) return;
        if (!Configuration.endPortalProtection.cleanExistingStructures) return;
        int chunks = 0;
        for (World world : Bukkit.getWorlds()) {
            for (Chunk chunk : world.getLoadedChunks()) {
                chunks += cleanChunk(chunk);
            }
        }
        if (chunks > 0) {
            XLogger.info("End portal protection: cleaned {0} block(s) left inside unactivated end portals.", chunks);
        }
    }

    /**
     * Scans one chunk for end portal frames and clears the middle of every complete
     * but unactivated portal found.
     *
     * @return how many blocks were removed
     */
    private int cleanChunk(Chunk chunk) {
        ChunkSnapshot snapshot = chunk.getChunkSnapshot();
        World world = chunk.getWorld();
        int minSection = world.getMinHeight() >> 4;
        int maxSection = (world.getMaxHeight() - 1) >> 4;
        Set<Long> checkedCenters = new HashSet<>();
        int removed = 0;

        for (int section = minSection; section <= maxSection; section++) {
            // the snapshot indexes sections from the bottom of the world, not by absolute Y
            if (snapshot.isSectionEmpty(section - minSection)) continue;
            int baseY = section << 4;
            for (int x = 0; x < 16; x++) {
                for (int z = 0; z < 16; z++) {
                    for (int y = baseY; y < baseY + 16; y++) {
                        if (snapshot.getBlockType(x, y, z) != Material.END_PORTAL_FRAME) continue;
                        int wx = (chunk.getX() << 4) + x;
                        int wz = (chunk.getZ() << 4) + z;
                        removed += cleanAroundFrame(world, wx, y, wz, checkedCenters);
                    }
                }
            }
        }
        return removed;
    }

    /**
     * Given one frame block, finds every portal center it could belong to and clears the
     * middle of the complete unactivated ones.
     */
    private int cleanAroundFrame(World world, int fx, int fy, int fz, Set<Long> checkedCenters) {
        int removed = 0;
        // a frame of the portal is 2 blocks away from the center on one axis at most
        for (int cx = fx - 2; cx <= fx + 2; cx++) {
            for (int cz = fz - 2; cz <= fz + 2; cz++) {
                long key = (((long) cx) << 32) | (cz & 0xffffffffL);
                if (!checkedCenters.add(key)) continue;
                if (!chunksAroundLoaded(world, cx, cz)) continue;
                if (!isCompleteFrame(world, cx, fy, cz)) continue;
                if (isActivated(world, cx, fy, cz)) continue;
                removed += clearInterior(world, cx, fy, cz);
            }
        }
        return removed;
    }

    /**
     * The 5x5 area of a portal may span into neighbouring chunks; only touch it
     * while every one of them is loaded, the rest is handled when they load.
     */
    private static boolean chunksAroundLoaded(World world, int cx, int cz) {
        for (int dx = -2; dx <= 2; dx += 4) {
            for (int dz = -2; dz <= 2; dz += 4) {
                if (!world.isChunkLoaded((cx + dx) >> 4, (cz + dz) >> 4)) return false;
            }
        }
        return true;
    }

    /**
     * Drops and removes every block inside the 3x3 of an unactivated portal.
     */
    private int clearInterior(World world, int cx, int y, int cz) {
        int removed = 0;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                Block block = world.getBlockAt(cx + dx, y, cz + dz);
                Material type = block.getType();
                if (type.isAir() || type == Material.END_PORTAL) continue;
                BlockState state = block.getState();
                if (state instanceof Container container) {
                    for (ItemStack item : container.getInventory().getContents()) {
                        if (item == null || item.getType().isAir()) continue;
                        world.dropItemNaturally(block.getLocation(), item);
                    }
                    container.getInventory().clear();
                }
                for (ItemStack drop : block.getDrops()) {
                    world.dropItemNaturally(block.getLocation(), drop);
                }
                block.setType(Material.AIR, false);
                removed++;
                XLogger.debug("End portal protection: removed {0} inside unactivated portal at {1}, {2}, {3}.",
                        type, block.getX(), block.getY(), block.getZ());
            }
        }
        return removed;
    }
}
