package cn.lunadeer.dominion;

import cn.lunadeer.dominion.cache.CacheManager;
import cn.lunadeer.dominion.configuration.Configuration;
import cn.lunadeer.dominion.configuration.Language;
import cn.lunadeer.dominion.events.EventsRegister;
import cn.lunadeer.dominion.managers.HooksManager;
import cn.lunadeer.dominion.managers.MultiServerManager;
import cn.lunadeer.dominion.managers.TeleportManager;
import cn.lunadeer.dominion.misc.InitCommands;
import cn.lunadeer.dominion.misc.Others;
import cn.lunadeer.dominion.uis.MainMenu;
import cn.lunadeer.dominion.utils.Notification;
import cn.lunadeer.dominion.utils.VaultConnect.VaultConnect;
import cn.lunadeer.dominion.utils.XLogger;
import cn.lunadeer.dominion.utils.XVersionManager;
import cn.lunadeer.dominion.utils.holograme.HoloManager;
import cn.lunadeer.dominion.nms.NMSManager;
import cn.lunadeer.dominion.utils.bStatsMetrics;
import cn.lunadeer.dominion.utils.command.CommandManager;
import cn.lunadeer.dominion.utils.configuration.ConfigurationPart;
import cn.lunadeer.dominion.storage.DatabaseManager;
import cn.lunadeer.dominion.utils.scheduler.Scheduler;
import cn.lunadeer.dominion.utils.scui.ChestUserInterfaceManager;
import cn.lunadeer.dominion.utils.stui.TextUserInterfaceManager;
import cn.lunadeer.dominion.utils.stui.inputter.Inputter;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class Dominion extends JavaPlugin {

    public static class DominionText extends ConfigurationPart {
        public String loadingConfig = "Loading Configurations...";
        public String pluginEnabled = "Plugin Enabled!";
        public String pluginVersion = "Plugin Version: {0}";
        public String notificationPrefix = "&6[&eDominion&6]&f";
    }

    @Override
    public void onEnable() {
        // Plugin startup logic
        instance = this;
        useOriginalDataFolder();
        new Notification(this);
        new XLogger(this);
        new Scheduler(this);

        // http://patorjk.com/software/taag/#p=display&f=Big&t=Dominion
        XLogger.info("  _____                  _       _");
        XLogger.info(" |  __ \\                (_)     (_)");
        XLogger.info(" | |  | | ___  _ __ ___  _ _ __  _  ___  _ __");
        XLogger.info(" | |  | |/ _ \\| '_ ` _ \\| | '_ \\| |/ _ \\| '_ \\");
        XLogger.info(" | |__| | (_) | | | | | | | | | | | (_) | | | |");
        XLogger.info(" |_____/ \\___/|_| |_| |_|_|_| |_|_|\\___/|_| |_|");
        XLogger.info(" ");
        XLogger.info(Language.dominionText.pluginVersion, this.getDescription().getVersion());

        try {
            XLogger.info(Language.dominionText.loadingConfig);
            Configuration.loadConfigurationAndDatabase(instance.getServer().getConsoleSender());
        } catch (Exception e) {
            XLogger.error(e);
            Bukkit.getServer().shutdown();  // Fatal error, shutdown server
            return;
        }
        Notification.instance.setPrefix(Language.dominionText.notificationPrefix);
        XVersionManager.VERSION = XVersionManager.GetVersion(this);
        NMSManager.initialize();

        new VaultConnect(this);
        new MultiServerManager(this);
        new TeleportManager(this);
        new CacheManager();
        new Inputter(this);
        new TextUserInterfaceManager(this);
        new ChestUserInterfaceManager(this);
        new DominionInterface();
        new HooksManager(this);

        new EventsRegister(this);
        new InitCommands();
        CommandManager commandManager = new CommandManager(this, "dominion", (sender) -> {
            MainMenu.show(sender, "1");
        });

        bStatsMetrics metrics = new bStatsMetrics(this, 21445);
        metrics.addCustomChart(new bStatsMetrics.SimplePie("database", () -> Configuration.database.type));
        metrics.addCustomChart(new bStatsMetrics.SingleLineChart("dominion_count", () -> CacheManager.instance.dominionCount()));
        metrics.addCustomChart(new bStatsMetrics.SingleLineChart("group_count", () -> CacheManager.instance.groupCount()));
        metrics.addCustomChart(new bStatsMetrics.SingleLineChart("member_count", () -> CacheManager.instance.memberCount()));

        XLogger.info(Language.dominionText.pluginEnabled);

        Others.autoClean();
    }

    /**
     * The plugin calls itself "Dominion-AntiDup622" so that this build can be told apart from
     * the upstream release, but Paper builds the data folder path from that name as well.
     * Servers already have their configuration and database in plugins/Dominion, so point the
     * data folder back there before anything touches the disk.
     * <p>
     * getDataFolder() is final and cannot be overridden, but it only returns a field that is
     * set once during plugin construction, so replacing that field is enough. saveResource()
     * reads the field directly as well, which keeps the bundled language files in place.
     */
    private void useOriginalDataFolder() {
        File originalFolder = new File(getServer().getPluginsFolder(), "Dominion");
        File renamedFolder = getDataFolder();
        if (originalFolder.equals(renamedFolder)) return;

        try {
            Field field = JavaPlugin.class.getDeclaredField("dataFolder");
            field.setAccessible(true);
            field.set(this, originalFolder);
        } catch (ReflectiveOperationException e) {
            getLogger().warning("Unable to keep the data folder at " + originalFolder.getPath()
                    + ", falling back to " + renamedFolder.getPath() + ": " + e.getMessage());
            return;
        }

        // An earlier build of this fork used its own folder for a while; adopt those files
        // instead of letting the server regenerate every configuration from scratch.
        if (!originalFolder.exists() && renamedFolder.isDirectory() && renamedFolder.renameTo(originalFolder)) {
            getLogger().info("Moved data folder " + renamedFolder.getName() + " to " + originalFolder.getName() + ".");
        }
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
        HoloManager.instance().removeAll(); // Clean up hologram display entities
        if (DatabaseManager.instance != null)
            DatabaseManager.instance.close();
        Scheduler.cancelAll();
    }

    public static Dominion instance;
    public static Map<UUID, Map<Integer, Location>> pointsSelect = new HashMap<>();

    public static String defaultPermission = "dominion.default";
    public static String adminPermission = "dominion.admin";
}
